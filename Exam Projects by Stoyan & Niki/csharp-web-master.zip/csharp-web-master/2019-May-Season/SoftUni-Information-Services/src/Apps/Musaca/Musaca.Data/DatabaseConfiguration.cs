﻿namespace Musaca.Data
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=MusacaDB;Trusted_Connection=True;Integrated Security=True;";
    }
}
