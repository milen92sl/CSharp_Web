﻿namespace IRunes.App.ViewModels.Tracks
{
    public class TrackDetailsViewModel
    {
        public string Name { get; set; }

        public string Price { get; set; }

        public string Link { get; set; }

        public string AlbumId { get; set; }
    }
}
