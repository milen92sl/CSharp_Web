﻿namespace IRunes.App.ViewModels.Albums
{
    public class AlbumAllViewModel
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}