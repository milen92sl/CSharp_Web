﻿namespace Stopify.Services.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapTo<T>
    {
    }
}
