﻿using System;

namespace Stopify.Web.ViewModels
{
    public class ProductCreateProductTypeViewModel
    {
        public string Name { get; set; }
    }
}
