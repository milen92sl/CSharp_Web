﻿namespace Panda.Domain
{
    public class PackageStatus
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}