let currentUsername = null;

// setInterval(loadMessages, 1000);