﻿namespace Demo.App.Models
{
    public class MessageCreateBindingModel
    {
        public string Content { get; set; }

        public string User { get; set; }
    }
}
