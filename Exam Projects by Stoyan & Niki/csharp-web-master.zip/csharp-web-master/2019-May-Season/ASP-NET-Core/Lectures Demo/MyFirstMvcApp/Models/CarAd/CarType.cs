﻿namespace MyFirstMvcApp.Models.CarAd
{
    public enum CarType
    {
        Sedan = 1,
        Suv = 2,
        Cabrio = 3,
        Combi = 4,
    }
}