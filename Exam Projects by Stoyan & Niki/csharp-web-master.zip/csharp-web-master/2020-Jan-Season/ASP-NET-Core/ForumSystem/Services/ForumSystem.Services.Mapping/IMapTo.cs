﻿namespace ForumSystem.Services.Mapping
{
    // ReSharper disable once UnusedTypeParameter
    public interface IMapTo<T>
    {
    }
}
