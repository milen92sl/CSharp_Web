﻿namespace ForumSystem.Web.ViewModels.Votes
{
    public class VoteResponseModel
    {
        public int VotesCount { get; set; }
    }
}
