﻿namespace ForumSystem.Data.Models
{
    public enum VoteType
    {
        DownVote = -1,
        Neutral = 0,
        UpVote = 1,
    }
}
